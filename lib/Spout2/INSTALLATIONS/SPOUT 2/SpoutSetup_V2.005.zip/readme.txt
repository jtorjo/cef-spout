Some notes on Spout 2.005 installation.

The new installer will prompt for removal of an existing installation. This is necessary because the installation folder structure has changed. There is no need to retain the old one, so click YES to this and it will be replaced.

Applications that have Spout built into the main program will not access the new features, such as the revised memoryshare option, until they update with the new SDK, but the existing function will not be changed.

The updated version of SpoutCam is installed automatically without any further action.

Contact us at spout.zeal.co

- - - - - - - - - - - - - -

